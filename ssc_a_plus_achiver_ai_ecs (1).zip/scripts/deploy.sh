#!/usr/bin/env bash
set -euo pipefail
: "${ECR_REPOSITORY?Need to set ECR_REPOSITORY env var}"
TAG=${1:-$(git rev-parse --short HEAD)}
aws ecr get-login-password --region ${AWS_REGION:-us-east-1} | docker login --username AWS --password-stdin ${ECR_REPOSITORY%%/*}
cd apps/api
docker build -t ${ECR_REPOSITORY}:$TAG -f Dockerfile .
docker push ${ECR_REPOSITORY}:$TAG
cd -
cd apps/web
npm ci
npm run build
aws s3 sync dist s3://${S3_BUCKET} --delete
cd -

echo "Deployed images:$TAG and frontend to s3://${S3_BUCKET}"
