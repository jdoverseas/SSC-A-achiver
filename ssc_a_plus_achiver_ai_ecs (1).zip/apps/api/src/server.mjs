import 'dotenv/config';
import express from 'express';
import cors from 'cors';
import mongoose from 'mongoose';
import { authRouter } from './routes/auth.mjs';
import { mcqRouter } from './routes/mcq.mjs';

const app = express();
app.use(cors({ origin: (process.env.ALLOWED_ORIGINS||'').split(',') }));
app.use(express.json({ limit: '2mb' }));

app.get('/health', (_, res)=> res.json({ ok: true, ts: new Date().toISOString() }));

app.use('/api/auth', authRouter);
app.use('/api/mcq', mcqRouter);

const PORT = process.env.PORT || 4000;
mongoose.connect(process.env.MONGO_URI).then(()=>{
  app.listen(PORT, ()=> console.log(`API listening on :${PORT}`));
}).catch(err=>{
  console.error('Mongo connect error', err);
  process.exit(1);
});
