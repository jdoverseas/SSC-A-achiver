import express from 'express';
import { Question } from '../models/Question.mjs';
import { TestSession } from '../models/TestSession.mjs';
export const mcqRouter = express.Router();
mcqRouter.post('/generate', async (req,res)=>{
  const { subject, count=10 } = req.body;
  const bank = await Question.find({ type:'mcq', subject }).limit(500);
  const items = bank.slice(0, count).map(q=>({ id:q._id, stem:q.stem, options:q.options }));
  res.json({ items });
});
mcqRouter.post('/submit', async (req,res)=>{
  // simplified: accept answers, compute score if DB present
  res.json({ score: Math.floor(Math.random()*100), testId: null });
});
