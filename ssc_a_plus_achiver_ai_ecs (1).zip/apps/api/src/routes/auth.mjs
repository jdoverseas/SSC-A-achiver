import express from 'express';
import bcrypt from 'bcryptjs';
import { User } from '../models/User.mjs';
import jwt from 'jsonwebtoken';
export const authRouter = express.Router();
authRouter.post('/register', async (req,res)=>{
  const { name, email, password } = req.body;
  if(!name||!email||!password) return res.status(400).json({ error:'missing' });
  const exists = await User.findOne({ email });
  if(exists) return res.status(409).json({ error:'Email in use' });
  const hash = await bcrypt.hash(password,10);
  const user = await User.create({ name, email, passwordHash: hash });
  const token = jwt.sign({ uid: user._id, role: user.role }, process.env.JWT_SECRET, { expiresIn: '7d' });
  res.json({ token, user:{ id:user._id, name:user.name, email } });
});
authRouter.post('/login', async (req,res)=>{
  const { email, password } = req.body;
  const user = await User.findOne({ email });
  if(!user) return res.status(401).json({ error:'Invalid' });
  const ok = await bcrypt.compare(password, user.passwordHash);
  if(!ok) return res.status(401).json({ error:'Invalid' });
  const token = jwt.sign({ uid: user._id, role: user.role }, process.env.JWT_SECRET, { expiresIn: '7d' });
  res.json({ token, user:{ id:user._id, name:user.name, email } });
});
