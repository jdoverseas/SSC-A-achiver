import mongoose from 'mongoose';
const questionSchema = new mongoose.Schema({
  type:{type:String,enum:['mcq','creative'],required:true},
  subject:{type:String,required:true},
  chapter:{type:String,required:true},
  yearTag:Number,
  stem:{type:String,required:true},
  options:[{text:String,key:String}],
  answerKey:String,
  explanation:String,
  difficulty:{type:Number,min:0,max:1,default:0.5},
  source:{type:String,enum:['ai','manual','past-paper'],default:'manual'}
},{timestamps:true});
export const Question = mongoose.model('Question', questionSchema);
