import mongoose from 'mongoose';
const testSessionSchema = new mongoose.Schema({
  userId:{ type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true },
  subject:String, chapter:String, mode:String,
  items:[{ qid:{ type: mongoose.Schema.Types.ObjectId, ref: 'Question' }, chosen:String, correct:Boolean }],
  score:Number, startedAt:Date, finishedAt:Date
},{timestamps:true});
export const TestSession = mongoose.model('TestSession', testSessionSchema);
