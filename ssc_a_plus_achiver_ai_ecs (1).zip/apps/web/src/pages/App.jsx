import React, { useState } from 'react';
export default function App(){
  const [tab,setTab]=useState('mcq');
  return (<div style={{fontFamily:'sans-serif',padding:20}}>
    <h1>SSC A+ Achiver AI (Demo)</h1>
    <nav style={{marginBottom:10}}>
      {['mcq','creative','reports','study','papers'].map(k=> <button key={k} onClick={()=>setTab(k)} style={{marginRight:6}}>{k}</button>)}
    </nav>
    <div>{tab==='mcq' && <div>MCQ Test UI (connect to /api)</div>}</div>
  </div>);
}
